% res = max2(m)     Overall maximum value of a multidimensional matrix

function res = max2(m)

res = max(m(:));