% res = min2(m)         Overall minimum value of a multidimensional matrix

function res = min2(m)
res = min(m(:));